// login() handles logging in
function login() {
    let user = document.getElementById('loguser').value;
    let pass = document.getElementById('logpass').value;
    
    if (user == "" || pass == "") {
        alert("invalid input");
        return;
    }
    const reqBody = {user, pass};
    
    let req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 201) {
            alert("Login successfully");
            window.location.href = "/home";
        }
        else if (this.readyState == 4 && this.status == 401)
            alert(`User name ${user} does not exits or password is wrong`);
    };
    req.open("POST", "/login");
    req.setRequestHeader("Content-Type", "application/json");
    req.send(JSON.stringify(reqBody));
}

// save() handles saving changes to privacy mode
function save() {
    let mode = document.getElementsByName('modename');
    let ans;
    for (i = 0; i < mode.length; i++) {
        if (mode[i].checked) {           
            ans = {signal : mode[i].value};
            break;
        }
    }
    if (!ans) {
        alert("Failed to save changes");
        return;
    } 

    let req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 201) {
            alert("Privacy mode changed successfully");
            window.location.href = "/users";
            return;
        }        
    };
    req.open("PUT", window.location.href);
    req.setRequestHeader("Content-Type", "application/json");
    req.send(JSON.stringify(ans));
}