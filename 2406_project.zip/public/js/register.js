//register() handles registering
function register() {
    let username = document.getElementById("createuser").value;
    let password = document.getElementById("createpass").value;

    if (username === "" || password === "") {
        alert("invalid input");
        return;
    }
    
    if (users.includes(username)) {
        alert("Username is taken, please choose a different one!");
        return ;
    }

    const reqBody = {"username" : username, "password" : password};

    let req = new XMLHttpRequest();
    req.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 201) {
            alert("new user is created");
        }
    };
    req.open("POST", "/register");
    req.setRequestHeader("Content-Type", "application/json");
    req.send(JSON.stringify(reqBody));
}